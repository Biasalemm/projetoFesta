package com.ProjetoFesta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoFestaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoFestaApplication.class, args);
	}

}
